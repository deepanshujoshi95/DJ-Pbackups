package com.cg.BackEndRest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.BackEndRest.dao.IRegisterMerchant;
import com.cg.BackEndRest.model.Merchant;


@Service("userServiceMerchant")
public class RegMerchantServiceImpl implements IRegMerchantService {
	
	@Autowired
	private IRegisterMerchant userDaoMerchant;
	
	@Override
	public void saveMerchant(Merchant merchant) {
		
		userDaoMerchant.save(merchant);	
	}

	@Override
	public List<Merchant> getAllMerchants() {
		
		return userDaoMerchant.findAll();
	}

}
