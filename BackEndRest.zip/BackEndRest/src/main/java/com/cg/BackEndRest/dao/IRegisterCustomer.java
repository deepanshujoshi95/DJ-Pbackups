package com.cg.BackEndRest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.BackEndRest.model.Customer;

@Repository("userDaoCust")
public interface IRegisterCustomer extends JpaRepository<Customer,Integer>{
	

}

