package com.cg.service;

import java.util.List;

import org.cap.model.ProductDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IProductDao;

@Service("pservice")
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	private IProductDao pdao;
	@Override
	public List<ProductDetails> getProducts() {
		
		return pdao.getProducts();
	}
	@Override
	public ProductDetails findProduct(Integer id) {

		return pdao.findProduct(id);
	}
	@Override
	public void updateProduct(ProductDetails product1) {
		
		pdao.updateProduct(product1);
		
		
	}

}
