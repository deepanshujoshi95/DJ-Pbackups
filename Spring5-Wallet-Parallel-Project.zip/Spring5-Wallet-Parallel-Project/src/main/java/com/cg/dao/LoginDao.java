package com.cg.dao;

public interface LoginDao {
	
	public boolean validateLogin(long customerId, String customerPwd);

	public String getCustomerName(int customerId);

}
