package com.cg.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.service.LoginService;


@Controller
public class MyController
{	
		@Autowired
		private LoginService loginService;
	
	
		@RequestMapping("/validatelogin")
		public String validateLogin(ModelMap map,
				@RequestParam("customerId") String id,
				@RequestParam("customerPwd")String customerPwd,
				HttpSession session)
		
		{	
			int customerId=Integer.parseInt(id);
			if(loginService.validateLogin(customerId, customerPwd))
			{
				map.put("customerName",loginService.getCustomerName(customerId));
				return "main";
			}
		return "redirect:/";
		}

		@RequestMapping("/createaccount")
		public String showcreateAccountPage()
		{
			return "createaccount";
		}
		
		@RequestMapping("/showbalance")
		public String showBalPage()
		{
			return "showbalance";
		}
		
		
		@RequestMapping("/deposit")
		public String deposit()
		{
			return "deposit";
			
		}
		@RequestMapping("/withdraw")
		public String withdraw()
		{
			return "withdraw";
			
		}
		@RequestMapping("/transfer")
		public String transfer()
		{
			return "transfer";
			
		}
		
		
		
			
}