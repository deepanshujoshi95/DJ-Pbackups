package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.LoginDao;

@Service("loginService")
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	private LoginDao loginDao;
	@Override
	public boolean validateLogin(long customerId, String customerPwd) {
		
		return loginDao.validateLogin(customerId, customerPwd);
	}
	@Override
	public String getCustomerName(int customerId) {
		
		return loginDao.getCustomerName(customerId);
	}

}
