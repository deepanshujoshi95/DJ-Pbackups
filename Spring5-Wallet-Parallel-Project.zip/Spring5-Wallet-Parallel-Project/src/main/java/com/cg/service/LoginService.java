package com.cg.service;

public interface LoginService {

	public boolean validateLogin(long customerId, String customerPwd);

	public String getCustomerName(int customerId);
}
