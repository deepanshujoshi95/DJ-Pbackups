function validateForm()
{
var uName=loginform.username.value;
var uPwd=loginform.password.value;
var flag=null;
if(uName=="" || uName==null)
	{
	document.getElementById('userErr').innerHTML=" Enter a User Name";
	}
else if(uPwd=="" || uPwd==null)
	{
	flag=false;
	document.getElementById('userErr').innerHTML="";
	document.getElementById('passErr').innerHTML=" Enter a Password";
	}
else
	{
	flag=true;
	document.getElementById('userErr').innerHTML="";
	document.getElementById('passErr').innerHTML="";
	}
	return flag;
}