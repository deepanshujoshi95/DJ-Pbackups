package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hotel.HotelDetails;

@Repository("bookingDao")
public class BookingDAOImpl implements IBookingDAO{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	@Transactional
	public List<HotelDetails> getAllHotels() {
		
		List<HotelDetails>allHotels=entityManager.createQuery("FROM HotelDetails").getResultList();
		return allHotels;
	}

	@Override
	public HotelDetails getHotelPageByName(String hName) {
	
	Query query=entityManager.createQuery("FROM HotelDetails where name=?");
	query.setParameter(0, hName);
	List<HotelDetails> selectedHotel=query.getResultList();
	return selectedHotel.get(0);
	}
}
