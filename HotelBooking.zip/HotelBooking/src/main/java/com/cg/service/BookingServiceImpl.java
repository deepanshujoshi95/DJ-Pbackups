package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IBookingDAO;
import com.cg.hotel.HotelDetails;

@Service("bookingService")
public class BookingServiceImpl implements IBookingService {
		
	@Autowired
	private IBookingDAO bookingDao;

	@Override
	public List<HotelDetails> getAllHotels() {
		return bookingDao.getAllHotels();
	}

	@Override
	public HotelDetails getHotelPageByName(String hName) {
		
		return bookingDao.getHotelPageByName(hName);
	}
	
}
