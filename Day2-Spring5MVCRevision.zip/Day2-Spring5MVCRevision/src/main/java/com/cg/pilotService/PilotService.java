package com.cg.pilotService;

import java.util.List;

import com.cg.model.Pilot;

public interface PilotService {
	
	public void save(Pilot pilot);
	public List<Pilot> getAll();
}
