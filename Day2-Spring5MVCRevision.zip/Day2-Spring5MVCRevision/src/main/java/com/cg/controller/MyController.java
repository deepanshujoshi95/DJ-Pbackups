package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.Pilot;
import com.cg.pilotService.PilotService;

@Controller
public class MyController
{
		@Autowired
		private PilotService pilotService;
		@RequestMapping("/hello")
		public ModelAndView sayHello()
		{
			String message ="Welcome !! Hello World";
			return new ModelAndView("helloPage","greetings",message);
		}
		
		@RequestMapping("/pilotForm")
			public String validate(ModelMap map,@RequestParam("username")String username, @RequestParam("passwrd" )String password)
			{
			if(username.equals("Tom") && password.equals("1234"))
					{	
						List<Pilot> pilots=pilotService.getAll();
						map.put("pilots",pilots);
						map.put("pilot",new Pilot());
						return "pilotForm";
					}
			return "redirect:/";
			}
		
		@RequestMapping("/pilotForm")
		public String getPilotForm(ModelMap map)
		{	
			List<Pilot> pilots=pilotService.getAll();
			map.put("pilots",pilots);
			map.put("pilot",new Pilot());
			return "pilotForm";
					
		}
		
		@PostMapping("/savePilot")
			public String savePilot(@Valid @ModelAttribute("pilot")Pilot pilot,BindingResult result)
			{
			if(!result.hasErrors()) {
				
				pilotService.save(pilot);
				//return "showPilot";
				}
				//return "pilotForm";
				return "redirect:pilotForm";
			}
		
			
}