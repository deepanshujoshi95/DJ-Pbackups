package com.cg.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.cg.model.Pilot;

@Repository("pilotDao")
@Transactional
public class PilotDaoImpl implements PilotDao {
	@PersistenceContext
	private EntityManager entityManager;
	//@Transactional
	@Override
	public void save(Pilot pilot) {
		
		entityManager.persist(pilot);
	}
	@Override
	public List<Pilot> getAll() {
		List<Pilot>pilots= entityManager.createQuery("from Pilot").getResultList();
		return pilots;
		
	}

}
