package com.cg.DAO;

import java.util.List;

import com.cg.model.Pilot;

public interface PilotDao {
	
	public void save(Pilot pilot);
	public List<Pilot> getAll();

}
